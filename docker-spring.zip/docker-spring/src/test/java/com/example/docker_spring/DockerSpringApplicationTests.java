package com.example.docker_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
